<?php
require_once ('layout.php');
page_header();
?>

<object width="840" height="500"> <param name="flashvars" value="offsite=true&lang=en-us&page_show_url=%2Fphotos%2F69886967%40N03%2Fsets%2F72157628040153577%2Fshow%2F&page_show_back_url=%2Fphotos%2F69886967%40N03%2Fsets%2F72157628040153577%2F&set_id=72157628040153577&jump_to="></param> <param name="movie" value="http://www.flickr.com/apps/slideshow/show.swf?v=109615"></param> <param name="allowFullScreen" value="true"></param><embed type="application/x-shockwave-flash" src="http://www.flickr.com/apps/slideshow/show.swf?v=109615" allowFullScreen="true" flashvars="offsite=true&lang=en-us&page_show_url=%2Fphotos%2F69886967%40N03%2Fsets%2F72157628040153577%2Fshow%2F&page_show_back_url=%2Fphotos%2F69886967%40N03%2Fsets%2F72157628040153577%2F&set_id=72157628040153577&jump_to=" width="840" height="500"></embed></object>

<?php
page_footer();
?>
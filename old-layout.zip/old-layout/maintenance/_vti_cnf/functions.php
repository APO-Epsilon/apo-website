vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Oct 2012 01:02:41 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{E0073D5C-4592-4F73-923D-E25C22D26175}
vti_cacheddtm:TX|16 Oct 2012 01:02:41 -0000
vti_filesize:IR|1628
vti_backlinkinfo:VX|

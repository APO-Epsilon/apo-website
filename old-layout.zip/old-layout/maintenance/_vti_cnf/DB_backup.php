vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Oct 2012 00:36:45 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{19410561-33E7-4D5B-B4B6-F1C9C7316D5B}
vti_cacheddtm:TX|16 Oct 2012 00:36:45 -0000
vti_filesize:IR|1454
vti_backlinkinfo:VX|

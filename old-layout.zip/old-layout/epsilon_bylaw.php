<?php
require_once ('layout.php');


page_header();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="css3menu1/style.css" type="text/css" />

</head>
<body style="background-color:#EBEBEB">
<ul id="css3menu1" class="topmenu">
	<li class="topfirst"><a href="#" style="width:259px;height:15px;line-height:15px;"><span>Epsilon</span></a>
	<ul>
		<li class="subfirst"><a href="http://apo.truman.edu/epsilon_bylaw.php">Bylaws</a></li>
		<li><a href="http://apo.truman.edu/epsilon_risk.php">Risk Management</a></li>
		<li><a href="http://apo.truman.edu/epsilon_jboard.php">Judicial Board</a></li>
	</ul>

	</li>
	<li class="topmenu"><a href="#" style="width:257px;height:15px;line-height:15px;"><span>National</span></a>
	<ul>
		<li class="subfirst"><a href="http://apo.truman.edu/national_bylaws.php">Bylaws</a></li>
		<li><a href="http://apo.truman.edu/national_risk.php">Risk Management</a></li>
	</ul>

	</li>
	<li class="toplast"><a href="http://apo.truman.edu/student_conduct.php" style="width:260px;height:15px;line-height:15px;">Student Code of Conduct</a></li>
</ul>


<p style="display:none"><a href="http://css3menu.com/">CSS3 Menu Top Css3Menu.com</a></p>




<div style="clear:both" />
<iframe src="http://docs.google.com/gview?url=http://apo.truman.edu/APOBylaws-Fall2013.docx&embedded=true" style="width:840px; height:600px;color:#EBEBEB;" frameborder="0"></iframe>


</div>
</body>
</html>
<?php
page_footer();
?>
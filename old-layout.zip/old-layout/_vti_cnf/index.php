vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Apr 2014 07:51:21 -0000
vti_extenderversion:SR|5.0.2.6790
vti_backlinkinfo:VX|index2.html
vti_author:SR|TRUMAN\\csweb06
vti_nexttolasttimemodified:TW|12 Feb 2014 01:52:03 -0000
vti_timecreated:TR|15 Jan 2013 15:13:37 -0000
vti_lineageid:SR|{C40E6408-F736-41D1-AE4C-9FC405FAD253}
vti_modifiedby:SR|TRUMAN\\jb2631
vti_cacheddtm:TX|11 Apr 2014 07:51:21 -0000
vti_filesize:IR|3996

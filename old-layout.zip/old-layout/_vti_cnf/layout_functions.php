vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Feb 2014 05:18:33 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{B9C641B5-65C1-43AE-9879-C36C42A71628}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\lom1272
vti_nexttolasttimemodified:TW|12 Nov 2013 17:54:55 -0000
vti_timecreated:TR|12 Feb 2014 01:49:54 -0000
vti_cacheddtm:TX|12 Feb 2014 01:49:54 -0000
vti_filesize:IR|12953

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Oct 2012 01:15:26 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{797BB5A6-61FF-45DC-9CB6-ACA1A5C56052}
vti_cacheddtm:TX|19 Oct 2012 01:15:26 -0000
vti_filesize:IR|2799
vti_backlinkinfo:VX|

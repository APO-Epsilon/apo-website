vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 Dec 2012 22:58:31 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{1D324394-B423-4F9F-93E5-5D9956C00649}
vti_cacheddtm:TX|15 Apr 2012 22:29:37 -0000
vti_filesize:IR|27074
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|06 Nov 2012 20:12:32 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{92C854A4-381D-4674-B005-C6E82559BDA3}
vti_cacheddtm:TX|02 Mar 2011 00:58:13 -0000
vti_filesize:IR|1917
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Dec 2012 02:20:44 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{2B5A6305-28F3-4DAC-A8DA-F1FD7E9B85D9}
vti_cacheddtm:TX|17 Dec 2012 02:20:44 -0000
vti_filesize:IR|3423
vti_backlinkinfo:VX|

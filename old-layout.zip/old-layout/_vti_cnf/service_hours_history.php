vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Aug 2012 22:44:14 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{194C3E3B-1877-4B86-B22F-30C69C41971E}
vti_cacheddtm:TX|20 Jan 2012 02:31:27 -0000
vti_filesize:IR|2392
vti_backlinkinfo:VX|

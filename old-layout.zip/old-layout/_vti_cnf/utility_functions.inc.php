vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Sep 2013 21:11:25 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{250CF468-830B-491B-866B-40E85F93A1A0}
vti_cacheddtm:TX|12 Sep 2013 21:11:25 -0000
vti_filesize:IR|154
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|28 Mar 2013 23:41:49 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{583446CC-2022-4E54-BDFC-6CFC5EFE72C6}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_modifiedby:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|28 Mar 2013 23:31:21 -0000
vti_timecreated:TR|28 Mar 2013 23:23:13 -0000
vti_cacheddtm:TX|28 Mar 2013 23:41:49 -0000
vti_filesize:IR|5617

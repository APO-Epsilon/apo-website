vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Oct 2012 15:49:24 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{F43E9449-A65B-4DB0-B1E9-2684E8F1A709}
vti_cacheddtm:TX|04 Dec 2011 01:52:11 -0000
vti_filesize:IR|1596
vti_backlinkinfo:VX|

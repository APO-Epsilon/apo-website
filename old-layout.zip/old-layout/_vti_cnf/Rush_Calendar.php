vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Aug 2014 01:33:25 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{F07CC964-446A-44D5-A5D8-43AED176B7D5}
vti_cacheddtm:TX|05 Sep 2012 00:49:50 -0000
vti_filesize:IR|320
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Nov 2013 18:02:05 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{5AF534D0-C9E8-4591-8928-3D3A5810AA39}
vti_cacheddtm:TX|17 Jan 2012 18:57:53 -0000
vti_filesize:IR|10211
vti_backlinkinfo:VX|

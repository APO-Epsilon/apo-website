vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|09 Oct 2012 19:21:18 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{77A243A6-2F57-4BD1-9A0A-4AAE8027DFD4}
vti_cacheddtm:TX|09 Oct 2012 19:21:18 -0000
vti_filesize:IR|1506
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|10 Feb 2012 23:23:28 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{932E2B4C-E29E-4BB6-A303-8C1F4AC31C05}
vti_cacheddtm:TX|10 Feb 2012 23:23:28 -0000
vti_filesize:IR|3035
vti_backlinkinfo:VX|

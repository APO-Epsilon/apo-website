vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Apr 2011 02:10:00 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{9B1ADF3F-3A40-442C-A22F-756155014455}
vti_cacheddtm:TX|18 Apr 2011 02:10:00 -0000
vti_filesize:IR|2488
vti_backlinkinfo:VX|

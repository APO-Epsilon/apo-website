vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 Aug 2012 21:16:52 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{A493BD90-3618-4E56-BCE0-F37165AE1574}
vti_cacheddtm:TX|26 Nov 2011 02:23:30 -0000
vti_filesize:IR|5287
vti_backlinkinfo:VX|

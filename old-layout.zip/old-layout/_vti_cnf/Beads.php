vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|29 Aug 2012 00:34:46 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{FF5A858E-E026-4597-991B-B9F817662EF0}
vti_cacheddtm:TX|29 Aug 2012 00:34:46 -0000
vti_filesize:IR|4653
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Jan 2013 22:22:42 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{6EBF5841-8BCC-4181-B188-B0A9029C8E8D}
vti_cacheddtm:TX|11 Jan 2013 07:30:11 -0000
vti_filesize:IR|73
vti_backlinkinfo:VX|

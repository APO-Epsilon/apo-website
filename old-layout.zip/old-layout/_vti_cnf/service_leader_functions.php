vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|10 Apr 2013 22:48:39 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{EAC5F6D6-1DCC-4718-B22F-22921C70F2D3}
vti_cacheddtm:TX|14 Jan 2013 21:33:29 -0000
vti_filesize:IR|6733
vti_backlinkinfo:VX|

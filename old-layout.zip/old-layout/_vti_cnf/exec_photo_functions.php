vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Sep 2013 21:45:56 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{9518931C-43E1-47C9-B60A-039CC00F2E61}
vti_cacheddtm:TX|12 Sep 2013 21:45:56 -0000
vti_filesize:IR|898
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Apr 2014 04:20:52 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{BC8212AF-D4F6-4B16-8F5E-AB7778CE077E}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\glb2268
vti_modifiedby:SR|TRUMAN\\glb2268
vti_nexttolasttimemodified:TW|29 Jan 2014 01:03:00 -0000
vti_timecreated:TR|11 Apr 2014 04:20:52 -0000
vti_cacheddtm:TX|11 Apr 2014 04:20:52 -0000
vti_filesize:IR|13505

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Oct 2011 21:36:02 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{753666BB-A7E7-4908-BA3D-024826E6A898}
vti_cacheddtm:TX|18 Oct 2011 21:36:02 -0000
vti_filesize:IR|4275
vti_backlinkinfo:VX|

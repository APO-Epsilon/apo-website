vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|15 Oct 2012 01:16:41 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{1E1ED978-BDCB-41AE-81D7-3198C3DA5690}
vti_cacheddtm:TX|09 Jan 2012 03:10:10 -0000
vti_filesize:IR|3298
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Oct 2012 00:58:59 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{6B7651FB-730C-4468-9DBA-D8E7B277ED94}
vti_cacheddtm:TX|17 Oct 2012 00:58:59 -0000
vti_filesize:IR|1545
vti_backlinkinfo:VX|

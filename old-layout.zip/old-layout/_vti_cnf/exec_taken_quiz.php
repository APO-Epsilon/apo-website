vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|21 Nov 2012 17:25:12 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{923EF885-A4BD-48C1-A0A9-AA3997F34D00}
vti_cacheddtm:TX|08 Nov 2010 01:48:29 -0000
vti_filesize:IR|1034
vti_backlinkinfo:VX|

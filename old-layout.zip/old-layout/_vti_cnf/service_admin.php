vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Feb 2014 05:31:00 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{69C87B61-2D02-434B-AA16-3FC9BC3F65C8}
vti_cacheddtm:TX|12 Jan 2013 17:04:40 -0000
vti_filesize:IR|1532
vti_backlinkinfo:VX|

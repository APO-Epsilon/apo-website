vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Oct 2012 16:02:06 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{4DF791DE-79AB-4A9C-B396-6642455C95F5}
vti_cacheddtm:TX|04 Dec 2011 01:52:32 -0000
vti_filesize:IR|1600
vti_backlinkinfo:VX|

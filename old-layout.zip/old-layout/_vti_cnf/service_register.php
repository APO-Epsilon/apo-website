vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Oct 2012 20:53:56 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{47D664F5-422D-4F7D-9AD6-F2CE226BF1B3}
vti_cacheddtm:TX|13 Oct 2012 20:53:56 -0000
vti_filesize:IR|3578
vti_backlinkinfo:VX|

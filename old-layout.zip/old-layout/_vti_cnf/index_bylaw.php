vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Oct 2012 05:19:52 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{764B3F94-197C-4055-AF49-047D456A2FCE}
vti_cacheddtm:TX|11 Oct 2012 05:19:52 -0000
vti_filesize:IR|4907
vti_backlinkinfo:VX|

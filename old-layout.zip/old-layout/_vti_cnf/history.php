vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Nov 2012 07:04:52 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{BA657BDD-BD1F-428B-BB1A-CFEAB214DD9D}
vti_cacheddtm:TX|20 Dec 2011 04:00:57 -0000
vti_filesize:IR|2523
vti_backlinkinfo:VX|

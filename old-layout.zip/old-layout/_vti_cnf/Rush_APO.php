vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Nov 2012 18:26:19 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{7DBC7BD5-FFC2-461E-BF1C-DDD49A20BF60}
vti_cacheddtm:TX|18 Nov 2012 18:26:19 -0000
vti_filesize:IR|466
vti_backlinkinfo:VX|

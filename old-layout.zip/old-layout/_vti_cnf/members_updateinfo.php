vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|10 Sep 2014 19:30:32 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{D331A4E0-3006-4D28-850B-EF9D7EB619FF}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|24 Jan 2013 20:56:58 -0000
vti_timecreated:TR|07 Mar 2013 23:12:49 -0000
vti_cacheddtm:TX|07 Mar 2013 23:12:49 -0000
vti_filesize:IR|8936

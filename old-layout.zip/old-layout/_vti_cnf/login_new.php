vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Feb 2011 05:56:19 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{3CF8CC73-3BBD-4370-9D1A-5E68D2E420A4}
vti_cacheddtm:TX|16 Feb 2011 05:56:19 -0000
vti_filesize:IR|4606
vti_backlinkinfo:VX|

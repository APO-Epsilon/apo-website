vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|15 Oct 2012 00:41:19 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{B8842A51-AC8D-4F6A-8C21-9EFA797C26BA}
vti_cacheddtm:TX|15 Oct 2012 00:41:19 -0000
vti_filesize:IR|958
vti_backlinkinfo:VX|

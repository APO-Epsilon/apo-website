vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|15 Jan 2013 15:07:33 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{5D79E29F-3969-4046-B2D5-BA41DB44C7F6}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\csweb06
vti_modifiedby:SR|TRUMAN\\csweb06
vti_nexttolasttimemodified:TW|15 Jan 2013 15:06:25 -0000
vti_timecreated:TR|15 Jan 2013 15:05:34 -0000
vti_cacheddtm:TX|15 Jan 2013 15:07:33 -0000
vti_filesize:IR|6556

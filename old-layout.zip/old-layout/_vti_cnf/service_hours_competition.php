vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|09 Apr 2011 17:39:14 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{9D9BAE66-8E59-44AF-AA3A-E82879E5937A}
vti_cacheddtm:TX|09 Apr 2011 17:39:14 -0000
vti_filesize:IR|4767
vti_backlinkinfo:VX|

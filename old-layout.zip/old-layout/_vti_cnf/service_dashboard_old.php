vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Jan 2013 20:54:06 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{BA58C0E8-9BAD-440F-A61D-483458B259C0}
vti_cacheddtm:TX|15 Jan 2013 19:30:13 -0000
vti_filesize:IR|6684
vti_backlinkinfo:VX|

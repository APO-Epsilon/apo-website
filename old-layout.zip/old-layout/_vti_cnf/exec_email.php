vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|06 Sep 2014 20:25:41 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{24ADA765-FB29-4D70-BB49-009AC1FBCA22}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|15 Apr 2013 20:16:18 -0000
vti_timecreated:TR|15 Apr 2013 20:11:18 -0000
vti_cacheddtm:TX|15 Apr 2013 20:16:50 -0000
vti_filesize:IR|2140

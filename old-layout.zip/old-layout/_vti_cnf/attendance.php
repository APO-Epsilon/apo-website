vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Oct 2012 13:40:14 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{6F177AD3-0382-40CA-BC3B-4287F75FF059}
vti_cacheddtm:TX|24 Oct 2012 13:40:14 -0000
vti_filesize:IR|5131
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Dec 2011 02:48:56 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{646E3F93-7A13-4AF1-8B27-D4CA340A8E20}
vti_cacheddtm:TX|19 Dec 2011 02:48:56 -0000
vti_filesize:IR|2086
vti_backlinkinfo:VX|

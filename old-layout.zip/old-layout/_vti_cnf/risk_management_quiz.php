vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|03 Dec 2013 00:12:02 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{A69E33C1-F23F-40F2-A1F9-D1E5082E5BBD}
vti_cacheddtm:TX|23 Sep 2011 04:26:58 -0000
vti_filesize:IR|6531
vti_backlinkinfo:VX|

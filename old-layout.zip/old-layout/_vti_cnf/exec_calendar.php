vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Aug 2010 15:50:28 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{8A090569-A8CA-46A0-9CFA-2581B4E7EE8D}
vti_cacheddtm:TX|30 Aug 2010 15:50:28 -0000
vti_filesize:IR|1105
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Feb 2014 05:31:36 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{95792A5B-63A2-4812-AFFA-5D79E0B146B3}
vti_cacheddtm:TX|14 Jan 2013 05:21:36 -0000
vti_filesize:IR|674
vti_backlinkinfo:VX|

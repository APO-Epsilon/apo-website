vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Jan 2014 18:29:16 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{5D844FE1-DF95-4B74-9EE5-84F59DB6B187}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|20 Jan 2013 23:32:18 -0000
vti_timecreated:TR|11 Apr 2013 19:21:37 -0000
vti_cacheddtm:TX|11 Apr 2013 19:21:37 -0000
vti_filesize:IR|18146

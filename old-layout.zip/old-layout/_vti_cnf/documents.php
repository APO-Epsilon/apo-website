vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|06 Jan 2012 23:17:34 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{D2D7006C-993A-444F-A2F9-FA5F10FF2D61}
vti_cacheddtm:TX|06 Jan 2012 23:17:34 -0000
vti_filesize:IR|1831
vti_backlinkinfo:VX|

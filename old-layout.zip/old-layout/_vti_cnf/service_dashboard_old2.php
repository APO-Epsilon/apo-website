vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Feb 2014 05:31:23 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{9845BC32-4A26-42C3-BB8B-88729C653274}
vti_cacheddtm:TX|15 Jan 2013 19:30:13 -0000
vti_filesize:IR|6684
vti_backlinkinfo:VX|

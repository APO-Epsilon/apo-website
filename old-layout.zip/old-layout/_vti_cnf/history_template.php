vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Dec 2011 03:34:41 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{C269B942-4A65-4C30-96D7-E63C64AF041F}
vti_cacheddtm:TX|19 Dec 2011 03:34:41 -0000
vti_filesize:IR|260
vti_backlinkinfo:VX|

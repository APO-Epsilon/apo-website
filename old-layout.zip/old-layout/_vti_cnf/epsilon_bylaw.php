vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|10 Nov 2013 00:16:00 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{074A1FE1-CED2-4CA6-974C-CE73523E284F}
vti_cacheddtm:TX|04 Dec 2011 01:52:41 -0000
vti_filesize:IR|1621
vti_backlinkinfo:VX|

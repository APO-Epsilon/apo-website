vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Dec 2011 15:44:57 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{93ED5731-8618-46DC-B220-5DA06CC07080}
vti_cacheddtm:TX|12 Dec 2011 15:44:57 -0000
vti_filesize:IR|302
vti_backlinkinfo:VX|

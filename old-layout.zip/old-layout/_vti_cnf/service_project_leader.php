vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|10 Nov 2012 03:31:18 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{55EDCCE9-B4BA-4245-B9A1-5D30411EFB20}
vti_cacheddtm:TX|10 Nov 2012 03:31:18 -0000
vti_filesize:IR|1094
vti_backlinkinfo:VX|

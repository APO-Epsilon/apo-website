vti_encoding:SR|utf8-nl
vti_author:SR|TRUMAN\\baw078
vti_modifiedby:SR|TRUMAN\\baw078
vti_timelastmodified:TR|11 Apr 2013 19:29:40 -0000
vti_timecreated:TR|10 Apr 2013 00:25:19 -0000
vti_title:SR|Untitled 1
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{6A80AD80-45E7-429D-9B39-953CCD049E33}
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|11 Apr 2013 19:29:29 -0000
vti_cacheddtm:TX|11 Apr 2013 19:29:40 -0000
vti_filesize:IR|775

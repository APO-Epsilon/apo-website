vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Mar 2013 23:10:30 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{13530704-EB7B-4004-A364-C6DDE35A76D2}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_modifiedby:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|19 Dec 2011 02:59:14 -0000
vti_timecreated:TR|26 Mar 2013 23:10:30 -0000
vti_cacheddtm:TX|26 Mar 2013 23:10:30 -0000
vti_filesize:IR|971

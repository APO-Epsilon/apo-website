vti_encoding:SR|utf8-nl
vti_author:SR|TRUMAN\\jb2631
vti_modifiedby:SR|TRUMAN\\jb2631
vti_timelastmodified:TR|23 Apr 2014 22:58:05 -0000
vti_timecreated:TR|23 Apr 2014 22:58:05 -0000
vti_lineageid:SR|{66AABC38-3D7D-4386-9820-78BC25C738F3}
vti_cacheddtm:TX|23 Apr 2014 22:58:05 -0000
vti_filesize:IR|4162
vti_extenderversion:SR|5.0.2.6790
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Feb 2014 05:27:15 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{CFEAE762-2C9B-4296-8898-3121DC02ADC6}
vti_cacheddtm:TX|13 Jan 2012 05:18:26 -0000
vti_filesize:IR|4435
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 Sep 2013 16:08:27 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{BACFB4A2-3452-4742-954C-38CF57E606B8}
vti_cacheddtm:TX|08 Nov 2012 21:56:51 -0000
vti_filesize:IR|1988
vti_backlinkinfo:VX|

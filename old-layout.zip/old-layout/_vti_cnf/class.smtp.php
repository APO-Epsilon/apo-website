vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|25 Aug 2010 20:49:43 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{F3D33260-7163-4AF5-8A1A-15E823816992}
vti_cacheddtm:TX|25 Aug 2010 20:49:43 -0000
vti_filesize:IR|34571
vti_backlinkinfo:VX|

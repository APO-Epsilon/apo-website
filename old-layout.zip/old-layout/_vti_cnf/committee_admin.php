vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|09 Nov 2012 18:09:14 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{F682B9EA-58E4-4EE8-A95E-343FEE7940FF}
vti_cacheddtm:TX|09 Nov 2012 18:09:14 -0000
vti_filesize:IR|13796
vti_backlinkinfo:VX|

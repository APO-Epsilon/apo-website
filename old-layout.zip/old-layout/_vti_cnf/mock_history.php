vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Nov 2012 06:41:08 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{B51897C2-EBDE-40C8-952E-984FE7D8F903}
vti_cacheddtm:TX|18 Nov 2012 06:41:08 -0000
vti_filesize:IR|204
vti_backlinkinfo:VX|

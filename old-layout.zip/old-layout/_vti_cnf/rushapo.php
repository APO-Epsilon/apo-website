vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Aug 2014 02:53:00 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{0214DF51-61FC-460F-A923-D843E2E63E4F}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\jb2631
vti_nexttolasttimemodified:TW|16 Apr 2014 07:33:02 -0000
vti_timecreated:TR|16 Apr 2014 02:58:37 -0000
vti_cacheddtm:TX|16 Apr 2014 07:33:40 -0000
vti_filesize:IR|5368

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Dec 2011 04:04:31 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{1DC3468B-D4FF-4454-93E8-52F63D0BFB4F}
vti_cacheddtm:TX|20 Dec 2011 04:04:31 -0000
vti_filesize:IR|1601
vti_backlinkinfo:VX|

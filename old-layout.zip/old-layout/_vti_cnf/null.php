vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Oct 2012 00:30:47 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{3ECBE566-BA6E-4F45-A723-0A6D1419F611}
vti_cacheddtm:TX|19 Oct 2012 00:30:47 -0000
vti_filesize:IR|0
vti_backlinkinfo:VX|

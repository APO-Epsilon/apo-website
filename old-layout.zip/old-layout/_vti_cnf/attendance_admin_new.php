vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Apr 2013 19:44:17 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{1382498C-6C8C-489E-89F9-939692F09CE2}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_modifiedby:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|20 Jan 2013 23:32:37 -0000
vti_timecreated:TR|11 Apr 2013 19:44:17 -0000
vti_cacheddtm:TX|11 Apr 2013 19:44:17 -0000
vti_filesize:IR|11730

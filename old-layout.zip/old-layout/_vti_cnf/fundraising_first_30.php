vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Jan 2012 16:39:17 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{FF505083-5505-460D-8F87-BCE6198700A4}
vti_cacheddtm:TX|17 Jan 2012 16:39:17 -0000
vti_filesize:IR|0
vti_backlinkinfo:VX|

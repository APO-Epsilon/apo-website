vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Jan 2012 17:04:29 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{DF6EE13E-C17C-41E4-92E0-D750862CE201}
vti_cacheddtm:TX|12 Jan 2012 17:04:29 -0000
vti_filesize:IR|1339
vti_backlinkinfo:VX|

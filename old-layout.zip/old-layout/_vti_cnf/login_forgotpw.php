vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|25 Aug 2010 21:15:08 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{6C9253E6-1EFA-4F31-B5D3-C04913A26376}
vti_cacheddtm:TX|25 Aug 2010 21:15:08 -0000
vti_filesize:IR|620
vti_backlinkinfo:VX|

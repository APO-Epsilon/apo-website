vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Apr 2014 03:05:55 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{FF14CD24-CF98-4EEB-A89A-A682694D371C}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|04 Nov 2013 01:42:26 -0000
vti_timecreated:TR|26 Mar 2013 23:29:10 -0000
vti_modifiedby:SR|TRUMAN\\jb2631
vti_cacheddtm:TX|16 Apr 2014 03:05:55 -0000
vti_filesize:IR|3623

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Dec 2011 02:28:25 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{3C90FA38-2595-4761-A0C1-B6B0C32E4E3A}
vti_cacheddtm:TX|19 Dec 2011 02:28:25 -0000
vti_filesize:IR|2220
vti_backlinkinfo:VX|

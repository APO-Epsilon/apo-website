vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Dec 2011 02:20:44 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{8196A03D-D35B-49CE-992C-3948426D112D}
vti_cacheddtm:TX|19 Dec 2011 02:20:44 -0000
vti_filesize:IR|944
vti_backlinkinfo:VX|

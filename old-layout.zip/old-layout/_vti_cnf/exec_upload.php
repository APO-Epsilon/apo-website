vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Oct 2012 04:09:53 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{C1F57427-8227-4D81-A3BB-AE43A5312560}
vti_cacheddtm:TX|19 Dec 2011 22:46:38 -0000
vti_filesize:IR|7250
vti_backlinkinfo:VX|

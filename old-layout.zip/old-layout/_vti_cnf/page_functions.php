vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Nov 2012 18:40:12 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{EE7EC08A-6409-4EEC-9D6D-A36916D1D35E}
vti_cacheddtm:TX|18 Nov 2012 18:40:12 -0000
vti_filesize:IR|3595
vti_backlinkinfo:VX|

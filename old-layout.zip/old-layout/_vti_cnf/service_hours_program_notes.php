vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Jan 2013 17:55:23 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{078776FA-C84E-4A4A-9047-4901C975E7CD}
vti_cacheddtm:TX|12 Jan 2013 17:55:23 -0000
vti_filesize:IR|2515
vti_backlinkinfo:VX|

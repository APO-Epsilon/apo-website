vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Oct 2012 05:17:59 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{8E220D5A-F2EA-4E95-9FA1-488A24261C8F}
vti_cacheddtm:TX|27 Oct 2011 17:32:37 -0000
vti_filesize:IR|428
vti_backlinkinfo:VX|

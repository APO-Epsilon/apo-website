vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Mar 2013 22:54:27 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{460132A6-48C0-407C-BDFC-ADD2B0F5431C}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_modifiedby:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|26 Mar 2013 22:47:28 -0000
vti_timecreated:TR|26 Mar 2013 22:42:12 -0000
vti_cacheddtm:TX|26 Mar 2013 22:54:27 -0000
vti_filesize:IR|1998

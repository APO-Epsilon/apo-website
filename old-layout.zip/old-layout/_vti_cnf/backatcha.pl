vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|06 May 2012 03:27:16 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{D5A03148-5C28-4A2B-B2A4-D08C3FF9D187}
vti_cacheddtm:TX|06 May 2012 03:27:16 -0000
vti_filesize:IR|1850
vti_backlinkinfo:VX|

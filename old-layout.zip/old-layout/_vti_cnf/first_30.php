vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Jan 2012 00:30:19 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{CC6F58A7-72BF-46AA-8E6C-9FB2D141CAAA}
vti_cacheddtm:TX|19 Jan 2012 00:30:19 -0000
vti_filesize:IR|1861
vti_backlinkinfo:VX|

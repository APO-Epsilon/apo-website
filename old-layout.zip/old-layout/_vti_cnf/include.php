vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Jan 2012 18:35:49 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{D5540C43-0AFC-47FD-8411-87A24D899489}
vti_cacheddtm:TX|13 Jan 2012 18:35:49 -0000
vti_filesize:IR|48
vti_backlinkinfo:VX|

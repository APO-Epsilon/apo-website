vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Jan 2012 02:18:07 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{A5889085-26A6-4769-B624-7204D2B6F160}
vti_cacheddtm:TX|19 Jan 2012 02:18:07 -0000
vti_filesize:IR|1844
vti_backlinkinfo:VX|

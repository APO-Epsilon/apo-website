vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Jan 2013 21:18:17 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{0E3A8451-5099-4A23-807D-7A6047F3F4BB}
vti_cacheddtm:TX|12 Jan 2013 06:44:00 -0000
vti_filesize:IR|5786
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Jan 2012 22:36:28 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{D1AA1C5B-F46D-4039-B16E-747DF70E8E76}
vti_cacheddtm:TX|19 Jan 2012 22:36:28 -0000
vti_filesize:IR|273
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|06 Nov 2012 22:46:03 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{3F4441D7-C4F4-4DFA-A573-60A3D3EAAC8B}
vti_cacheddtm:TX|06 Nov 2012 22:46:03 -0000
vti_filesize:IR|1745
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Nov 2013 18:02:38 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{ADB3E680-4E10-433C-AAA2-19E3CAE07EAE}
vti_cacheddtm:TX|06 Nov 2012 19:38:33 -0000
vti_filesize:IR|5077
vti_backlinkinfo:VX|

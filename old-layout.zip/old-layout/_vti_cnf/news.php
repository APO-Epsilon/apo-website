vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|06 Nov 2012 22:14:39 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{5BE012D3-D695-4650-B337-0B3BE3DC3537}
vti_cacheddtm:TX|06 Nov 2012 22:14:39 -0000
vti_filesize:IR|814
vti_backlinkinfo:VX|

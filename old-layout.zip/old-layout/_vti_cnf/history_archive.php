vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Apr 2014 07:36:27 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{A898C40A-5F9F-414E-9792-9BD7A310C23C}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\jb2631
vti_modifiedby:SR|TRUMAN\\jb2631
vti_nexttolasttimemodified:TW|16 Apr 2014 07:35:57 -0000
vti_timecreated:TR|16 Apr 2014 07:35:57 -0000
vti_cacheddtm:TX|16 Apr 2014 07:36:27 -0000
vti_filesize:IR|2530

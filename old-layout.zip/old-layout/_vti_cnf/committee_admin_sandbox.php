vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Nov 2013 20:45:56 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{10725197-3361-4B3D-9887-DE06F698D142}
vti_cacheddtm:TX|20 Nov 2013 20:45:56 -0000
vti_filesize:IR|13804
vti_backlinkinfo:VX|

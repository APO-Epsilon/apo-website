vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Jan 2012 04:19:34 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{34970593-9E9F-4FE7-91A1-E93B2720F1C2}
vti_cacheddtm:TX|13 Jan 2012 04:19:34 -0000
vti_filesize:IR|2323
vti_backlinkinfo:VX|

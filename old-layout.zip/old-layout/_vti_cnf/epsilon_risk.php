vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|04 Dec 2011 01:52:19 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{C7EDFD27-FF9E-40CA-BF8E-9798E79A87BD}
vti_cacheddtm:TX|04 Dec 2011 01:52:19 -0000
vti_filesize:IR|1604
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Mar 2013 00:21:45 -0000
vti_extenderversion:SR|5.0.2.6790
vti_author:SR|TRUMAN\\baw078
vti_modifiedby:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TR|07 Mar 2013 23:19:17 -0000
vti_timecreated:TR|19 Feb 2013 03:27:45 -0000
vti_parentlineageid:SR|{37DBA007-1ECA-4586-88F5-C68585D1BC53}
vti_lineageid:SR|{2F34B06B-1112-4FE0-86D1-91FB84293DD5}
vti_cacheddtm:TX|08 Mar 2013 00:21:45 -0000
vti_filesize:IR|16822
vti_backlinkinfo:VX|

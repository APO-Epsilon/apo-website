vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Mar 2013 23:02:36 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{2C0C9E7B-C31D-4EB3-BF93-799D8DC27862}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_modifiedby:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|26 Mar 2013 23:01:24 -0000
vti_timecreated:TR|26 Mar 2013 23:01:24 -0000
vti_cacheddtm:TX|26 Mar 2013 23:02:36 -0000
vti_filesize:IR|1120

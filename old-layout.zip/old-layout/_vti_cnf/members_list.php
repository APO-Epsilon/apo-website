vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Jan 2013 21:01:39 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{53D9C996-B12D-4A54-A536-2BF8A305D163}
vti_cacheddtm:TX|02 Mar 2011 01:13:42 -0000
vti_filesize:IR|5514
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 Jan 2012 01:49:44 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{0C2CEBF7-BC18-4E90-AE1D-70FF37203C8A}
vti_cacheddtm:TX|23 Jan 2012 01:49:44 -0000
vti_filesize:IR|798
vti_backlinkinfo:VX|

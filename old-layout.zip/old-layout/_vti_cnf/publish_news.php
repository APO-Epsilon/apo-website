vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|07 Nov 2012 15:48:33 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{AC66D619-B3A3-4B2A-AC58-3659A94BB000}
vti_cacheddtm:TX|07 Nov 2012 15:48:33 -0000
vti_filesize:IR|2190
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Oct 2013 23:44:48 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{060158B5-5790-424C-9BA4-BE8E988F769D}
vti_cacheddtm:TX|22 Jan 2012 23:43:00 -0000
vti_filesize:IR|3260
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Apr 2014 04:17:37 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{2DC18A22-E311-4506-B2C4-745BBDFB3B60}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\glb2268
vti_modifiedby:SR|TRUMAN\\glb2268
vti_nexttolasttimemodified:TW|11 Apr 2014 04:17:36 -0000
vti_timecreated:TR|11 Apr 2014 04:05:20 -0000
vti_cacheddtm:TX|11 Apr 2014 04:12:54 -0000
vti_filesize:IR|13185

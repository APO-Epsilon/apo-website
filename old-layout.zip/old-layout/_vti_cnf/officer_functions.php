vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Nov 2013 02:00:45 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{EDDA45A4-0E11-47E5-B64F-CAA8A39A2022}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\lom1272
vti_nexttolasttimemodified:TW|28 Mar 2013 23:16:38 -0000
vti_timecreated:TR|25 Jan 2013 00:28:30 -0000
vti_cacheddtm:TX|28 Mar 2013 23:17:00 -0000
vti_filesize:IR|2929

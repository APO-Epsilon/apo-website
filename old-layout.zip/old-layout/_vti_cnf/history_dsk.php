vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Mar 2013 23:12:12 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{2103446E-8D57-448A-A0C9-4458854DB009}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_modifiedby:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|23 Apr 2012 21:15:01 -0000
vti_timecreated:TR|26 Mar 2013 23:12:12 -0000
vti_cacheddtm:TX|26 Mar 2013 23:12:12 -0000
vti_filesize:IR|1609

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|14 Jan 2014 18:35:27 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{64A30BB3-22E5-4184-BC7F-37E0A2E9E07A}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|24 Oct 2012 13:35:02 -0000
vti_timecreated:TR|04 Feb 2013 22:37:27 -0000
vti_cacheddtm:TX|04 Feb 2013 22:37:27 -0000
vti_filesize:IR|8807

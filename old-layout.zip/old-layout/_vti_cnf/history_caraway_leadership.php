vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 Apr 2012 21:11:33 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{42A40BA9-EE92-45EC-A027-CF4B92FD9D01}
vti_cacheddtm:TX|23 Apr 2012 21:11:33 -0000
vti_filesize:IR|1257
vti_backlinkinfo:VX|

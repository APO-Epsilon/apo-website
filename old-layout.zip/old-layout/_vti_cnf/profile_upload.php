vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Sep 2013 14:45:11 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{C1F27BB2-D198-4332-A4CB-0C466A5DF19E}
vti_cacheddtm:TX|12 Sep 2013 14:45:11 -0000
vti_filesize:IR|587
vti_backlinkinfo:VX|

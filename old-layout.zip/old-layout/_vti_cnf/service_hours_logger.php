vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Jan 2013 02:43:19 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{727387D3-1CD7-46DC-AFD1-21471CE1ED5A}
vti_cacheddtm:TX|11 Jan 2013 16:08:34 -0000
vti_filesize:IR|2429
vti_backlinkinfo:VX|

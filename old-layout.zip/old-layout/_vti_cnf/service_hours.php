vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Feb 2014 00:30:57 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{85061691-E8CE-445F-AA68-EF7F8813B05B}
vti_cacheddtm:TX|07 Feb 2012 21:36:07 -0000
vti_filesize:IR|13150
vti_backlinkinfo:VX|

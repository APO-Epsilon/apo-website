vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Dec 2011 04:27:24 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{284EDCE5-F2C7-49AB-81B8-1A6CDABA7117}
vti_cacheddtm:TX|20 Dec 2011 04:27:24 -0000
vti_filesize:IR|12143
vti_backlinkinfo:VX|

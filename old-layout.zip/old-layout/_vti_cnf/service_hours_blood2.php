vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Nov 2011 20:32:19 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{BE9CDD82-16AE-4EE3-AB1D-68AE9DEEF5D0}
vti_cacheddtm:TX|13 Nov 2011 20:32:19 -0000
vti_filesize:IR|4424
vti_backlinkinfo:VX|

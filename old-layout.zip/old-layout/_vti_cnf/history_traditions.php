vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Feb 2014 00:31:32 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{4EAE3B67-9344-485F-A361-52EB384E5101}
vti_cacheddtm:TX|16 Feb 2011 16:21:51 -0000
vti_filesize:IR|15088
vti_backlinkinfo:VX|

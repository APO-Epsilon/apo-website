vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Feb 2014 05:29:51 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{80C1D5EA-A975-4614-BA67-086E8ABF4A7D}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|21 Mar 2013 22:28:51 -0000
vti_timecreated:TR|21 Mar 2013 22:28:11 -0000
vti_cacheddtm:TX|21 Mar 2013 22:31:39 -0000
vti_filesize:IR|5769

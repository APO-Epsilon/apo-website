vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Nov 2011 18:47:12 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{8F90CB5B-69B6-4C3B-91F3-77F615A2080E}
vti_cacheddtm:TX|18 Nov 2011 18:47:12 -0000
vti_filesize:IR|903
vti_backlinkinfo:VX|

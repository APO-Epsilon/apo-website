vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Feb 2011 16:21:51 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{FF7D5F97-7C7F-4C98-AB4D-BA5941105AE1}
vti_cacheddtm:TX|16 Feb 2011 16:21:51 -0000
vti_filesize:IR|15088
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Feb 2014 05:30:22 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{37DBA007-1ECA-4586-88F5-C68585D1BC53}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|08 Mar 2013 00:27:04 -0000
vti_timecreated:TR|19 Feb 2013 03:27:45 -0000
vti_cacheddtm:TX|18 Mar 2013 02:52:26 -0000
vti_filesize:IR|16771

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Jan 2012 05:25:31 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{6E47613C-EC58-40E9-AB93-359E91F77F26}
vti_cacheddtm:TX|13 Jan 2012 05:25:31 -0000
vti_filesize:IR|1033
vti_backlinkinfo:VX|

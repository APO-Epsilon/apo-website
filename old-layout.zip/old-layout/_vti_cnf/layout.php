vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|02 Sep 2014 20:08:49 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{F7D4FEE7-3DAD-4B81-88EC-3CC7A6E842F0}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\lom1272
vti_nexttolasttimemodified:TW|26 Feb 2014 05:18:29 -0000
vti_timecreated:TR|25 Jan 2013 00:24:36 -0000
vti_cacheddtm:TX|20 Apr 2014 06:18:57 -0000
vti_filesize:IR|13864

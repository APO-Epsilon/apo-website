vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Jan 2012 03:34:59 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{169226F8-BA97-4AD6-9048-1675CB96F00A}
vti_cacheddtm:TX|11 Jan 2012 03:34:59 -0000
vti_filesize:IR|4460
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Nov 2012 23:29:31 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{44761BDF-1053-4E8B-8B42-2966A30F18D2}
vti_cacheddtm:TX|08 Nov 2012 23:29:31 -0000
vti_filesize:IR|2149
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|30 Jan 2013 00:30:35 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{BFEDFF9C-61EE-4B85-8E45-1488DF9A2F7F}
vti_cacheddtm:TX|10 Dec 2012 04:50:56 -0000
vti_filesize:IR|5993
vti_backlinkinfo:VX|

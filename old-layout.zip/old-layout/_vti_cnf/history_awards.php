vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Dec 2011 02:51:08 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{0B6B5E2A-474D-4BCA-B4DA-AE643A0881FD}
vti_cacheddtm:TX|19 Dec 2011 02:51:08 -0000
vti_filesize:IR|1168
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Jan 2013 21:02:28 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{DCD06DE2-1305-4143-831A-90AC0D6F7D1A}
vti_cacheddtm:TX|12 Jan 2013 06:21:35 -0000
vti_filesize:IR|4447
vti_backlinkinfo:VX|

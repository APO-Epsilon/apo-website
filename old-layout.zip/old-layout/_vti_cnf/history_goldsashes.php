vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Mar 2013 22:58:59 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{F6BFC03B-3306-4728-AE96-D7932D080447}
vti_backlinkinfo:VX|
vti_author:SR|TRUMAN\\baw078
vti_modifiedby:SR|TRUMAN\\baw078
vti_nexttolasttimemodified:TW|24 Apr 2012 00:32:21 -0000
vti_timecreated:TR|26 Mar 2013 22:58:59 -0000
vti_cacheddtm:TX|26 Mar 2013 22:58:59 -0000
vti_filesize:IR|8778

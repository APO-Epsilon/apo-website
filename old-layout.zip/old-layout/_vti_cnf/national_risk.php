vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|04 Dec 2011 01:52:02 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{232FD770-7E3C-41F8-80F0-4F71AE72CA41}
vti_cacheddtm:TX|04 Dec 2011 01:52:02 -0000
vti_filesize:IR|1599
vti_backlinkinfo:VX|

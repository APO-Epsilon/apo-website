<?php
require_once ('layout.php');
require_once ('mysql_access.php');
require_once ('officer_functions.php');
page_header();
echo ('<div class= "content">');

echo('<br /><iframe src="http://familyecho.com/?p=GT11Y&c=gcv7hl4fx6&f=484622734175584762#view:GT11Y" width="790" height="800"></iframe>');

echo('</div>');
page_footer();?>
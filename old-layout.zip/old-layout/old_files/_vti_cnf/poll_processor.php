vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|15 Jan 2012 22:48:41 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{CC23DC41-A780-4A3E-B333-973ADA559757}
vti_cacheddtm:TX|15 Jan 2012 22:48:41 -0000
vti_filesize:IR|1240
vti_backlinkinfo:VX|

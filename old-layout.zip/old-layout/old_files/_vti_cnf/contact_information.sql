vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Jan 2012 22:02:29 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{00826666-BB63-4281-B039-25098323D594}
vti_cacheddtm:TX|19 Jan 2012 22:02:29 -0000
vti_filesize:IR|63461
vti_backlinkinfo:VX|

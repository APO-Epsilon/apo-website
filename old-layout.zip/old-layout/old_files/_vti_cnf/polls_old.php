vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|15 Jan 2012 22:53:51 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{EF282AC3-4E84-4947-B44B-CE1DD2C3A0C4}
vti_cacheddtm:TX|15 Jan 2012 22:53:51 -0000
vti_filesize:IR|3662
vti_backlinkinfo:VX|

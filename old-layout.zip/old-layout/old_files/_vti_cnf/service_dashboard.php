vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Jan 2012 05:18:26 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{615C9FF7-2349-42E4-BFA7-B98CC79D2BEC}
vti_cacheddtm:TX|13 Jan 2012 05:18:26 -0000
vti_filesize:IR|4435
vti_backlinkinfo:VX|

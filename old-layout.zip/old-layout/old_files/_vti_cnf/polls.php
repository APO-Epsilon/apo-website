vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 Apr 2012 20:38:22 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{87E67A32-A637-492E-BDFB-8DC7E9803C95}
vti_cacheddtm:TX|23 Apr 2012 20:38:22 -0000
vti_filesize:IR|9832
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Nov 2012 03:52:42 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{0A3424FF-3170-4EA1-B78A-B9DF6ADD4280}
vti_cacheddtm:TX|20 Nov 2012 03:52:42 -0000
vti_filesize:IR|12243
vti_backlinkinfo:VX|

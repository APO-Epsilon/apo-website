vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Nov 2012 03:52:42 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{32C64757-77A2-4682-9C66-0056B63B8474}
vti_cacheddtm:TX|20 Nov 2012 03:52:42 -0000
vti_filesize:IR|466
vti_backlinkinfo:VX|

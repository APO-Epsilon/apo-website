vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Nov 2012 03:52:42 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{D4029EF1-B6D8-410D-8702-B943C0311175}
vti_cacheddtm:TX|20 Nov 2012 03:52:42 -0000
vti_filesize:IR|5860
vti_backlinkinfo:VX|

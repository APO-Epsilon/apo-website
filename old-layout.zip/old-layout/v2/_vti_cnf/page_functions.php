vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Nov 2012 03:52:42 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{81AA3F31-7650-4DBC-9519-B4E7384DB7B5}
vti_cacheddtm:TX|20 Nov 2012 03:52:42 -0000
vti_filesize:IR|3595
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Nov 2012 03:52:42 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{77C70FFB-676A-4651-AC92-673BD46F08AA}
vti_cacheddtm:TX|20 Nov 2012 03:52:42 -0000
vti_filesize:IR|3906
vti_backlinkinfo:VX|

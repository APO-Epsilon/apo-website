vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Nov 2012 03:52:42 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{C031D9B0-3536-4EB8-AA1F-F26C49BB734B}
vti_cacheddtm:TX|20 Nov 2012 03:52:42 -0000
vti_filesize:IR|273
vti_backlinkinfo:VX|

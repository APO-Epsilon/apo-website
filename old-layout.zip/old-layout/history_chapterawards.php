<?php
require_once ('layout.php');
page_header();
?>
<div class="content">
<h1>Awards Epsilon Has Received</h1>
<div class="entry">
<b>H. Roe Bartle Award Winner</b><br>
        1975-1976<br />
        1976-1977<br />
        1977-1978<br />
        1978-1979<br />
        1979-1980<br />
        1980-1981<br />
        1981-1982<br />
        1983-1984<br />
        1984-1985<br />
        1989-1990<br />
        1994-1995<p>
	<b>Joseph Scanlon Award Winner</b><br />
	  	 1989-1990<br />
		 1991-1992<br />
		 1993-1994<br />
		 1994-1995<br />
		 1996-1997<p>		  		
    <b>Truman State University Outstanding Large Organization of the Year</b><br />
	     1992-1993<br />
		 1995-1996<br />
		 1996-1997<br />
		 1997-1998<p>
	<b>Homecoming Awards</b><br />
	     1981 - 1st Place Pep Rally Skit Contest<br />
		 1990 - 1st Place NMSU Pursuit<br />
		 1996 - 1st Place Trivial Pursuit<br />
		 1997 - 1st Place Banner Competition<br />
		 1997 - 3rd Place Lip Sync Competition<br />
		 1997 - 2nd Place Philanthropy Cans Competition<br />
		 2003 - 1st Place Volleyball and Ultimate Frisbee<br />
		 2003 - 2nd Place Overall, Banner Competition, Philanthropy Competition, Most Spirited Organization, Flag Football, and Trivial Pursuit<br />
		 2003 - 3rd Place Scavenger Hunt and Street Graffiti<br />
		 2004 - 3rd Place Overall<br />
		 2005 - 1st Place Banner, 2nd Place Graffiti, 3rd Place Skits<p>
	<b>Section 49 Conference Man-Mile Award</b><br />
	     1997, 2003<br /><p>
	<b>Region VIII Conference Man-Mile Award</b><br />
		 1991, 2003, 2005<p>
    <b>Intramural Victories</b><br />
	  	 1997 - Softball, Co-ed Open Division 1st Place<br />
		 2005 - Soccer, Girls Open Division 2nd Place<br /> 		 
      	 Third Place 1984 Six Person Downhill Waterbed Race<br /> 
     	 Kirksville Community Betterment Council Group Project of the Year Award<br /> 
     	 1986 Dance Marathon<br /> 
      	 Third Place 1986 Pepsi-KOMC and Wal-Mart Arthritis Volleyball Tournament<br /> 
  </div>
</div>
<?php
page_footer();
?>
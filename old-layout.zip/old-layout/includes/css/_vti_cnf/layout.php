vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Oct 2012 04:30:56 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{DAFBC4DF-26CD-4D3C-BAD8-44A99B54AC64}
vti_cacheddtm:TX|12 Oct 2012 04:30:56 -0000
vti_filesize:IR|11981
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Oct 2012 08:29:16 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{8B3593ED-EE0C-47CA-8509-AAA17B925EA9}
vti_cacheddtm:TX|12 Oct 2012 08:29:16 -0000
vti_filesize:IR|1309
vti_backlinkinfo:VX|

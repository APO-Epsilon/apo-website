vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|10 Dec 2012 05:42:16 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{4EC3405A-2213-4FDD-A73A-B713B25CF4FA}
vti_cacheddtm:TX|10 Dec 2012 05:42:16 -0000
vti_filesize:IR|58516
vti_backlinkinfo:VX|

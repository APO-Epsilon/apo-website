vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Sep 2013 14:05:49 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{81C40141-FABB-418A-88CD-BC4561AEC7F1}
vti_cacheddtm:TX|13 Sep 2013 14:05:49 -0000
vti_filesize:IR|31033
vti_backlinkinfo:VX|

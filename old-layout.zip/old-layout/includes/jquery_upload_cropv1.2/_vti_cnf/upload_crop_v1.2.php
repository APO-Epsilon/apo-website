vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Sep 2013 14:13:10 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{45575184-FA33-4094-9669-09143377B6E8}
vti_cacheddtm:TX|13 Sep 2013 14:13:10 -0000
vti_filesize:IR|16385
vti_backlinkinfo:VX|

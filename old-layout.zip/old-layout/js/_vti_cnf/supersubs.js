vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|25 Dec 2011 03:58:45 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{1D737F5A-42DF-4A69-B47D-EF38C5748AD6}
vti_cacheddtm:TX|25 Dec 2011 03:58:45 -0000
vti_filesize:IR|3298
vti_backlinkinfo:VX|

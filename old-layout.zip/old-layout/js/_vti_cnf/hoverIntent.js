vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|25 Dec 2011 03:58:44 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{906A7B10-7C25-4653-95D9-8BB04F2024F3}
vti_cacheddtm:TX|25 Dec 2011 03:58:44 -0000
vti_filesize:IR|3174
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|10 Dec 2012 05:36:23 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{40FFA085-5A12-44C4-8EF5-CD50814D2B44}
vti_cacheddtm:TX|10 Dec 2012 05:36:23 -0000
vti_filesize:IR|732
vti_backlinkinfo:VX|

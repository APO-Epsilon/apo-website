vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|25 Dec 2011 03:58:45 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{9F1AF822-EE31-4060-B6BC-2D61DA233BA8}
vti_cacheddtm:TX|25 Dec 2011 03:58:45 -0000
vti_filesize:IR|3714
vti_backlinkinfo:VX|

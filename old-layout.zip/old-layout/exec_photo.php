<html>
<body>

<form action="upload_exec_photo.php" method="post"
enctype="multipart/form-data">
<label for="file">Filename:</label>
<input type="file" name="uploaded_file" id="uploaded_file"><br>
<input type="submit" name="submit" value="Submit">
</form>

</body>
</html>
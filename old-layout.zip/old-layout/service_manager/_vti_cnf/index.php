vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Oct 2012 00:20:02 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{AE5124DC-F68F-42A4-8854-BEA4227103B0}
vti_cacheddtm:TX|27 Oct 2012 00:20:02 -0000
vti_filesize:IR|595
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Oct 2012 22:49:51 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{A96D3C67-7A7D-4CEC-96B2-5F06D01A4508}
vti_cacheddtm:TX|26 Oct 2012 22:49:51 -0000
vti_filesize:IR|1519
vti_backlinkinfo:VX|

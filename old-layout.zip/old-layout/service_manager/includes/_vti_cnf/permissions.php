vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Oct 2012 23:40:17 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{99B8F2F9-ED24-4AFD-B251-55681A066080}
vti_cacheddtm:TX|26 Oct 2012 23:40:17 -0000
vti_filesize:IR|892
vti_backlinkinfo:VX|

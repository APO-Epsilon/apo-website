<?php
require_once ('layout.php');

page_header();
?>

<div class="content">
<h1>APO Update Calendar</h1>

<div style="margin: 0px auto; width: 750px;">
<iframe src="https://www.google.com/calendar/embed?src=h84dpe9q6v9eft0vpgbbdmf2so%40group.calendar.google.com&ctz=America/Chicago" style="border: 0" width="750" height="600" frameborder="0" scrolling="yes"></iframe>
</div>
<?php
echo "</div>";
page_footer();
?>
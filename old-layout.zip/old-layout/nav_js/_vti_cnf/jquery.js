vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|18 Jan 2012 04:26:03 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{265FE785-9232-47CA-B377-DB3ABA6276CC}
vti_cacheddtm:TX|18 Jan 2012 04:26:03 -0000
vti_filesize:IR|29846
vti_backlinkinfo:VX|

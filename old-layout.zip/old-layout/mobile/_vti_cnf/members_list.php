vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|15 Oct 2012 23:40:01 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{EA4C3761-7C4B-4D8B-8EBC-ED203D084793}
vti_cacheddtm:TX|15 Oct 2012 23:40:01 -0000
vti_filesize:IR|2513
vti_backlinkinfo:VX|

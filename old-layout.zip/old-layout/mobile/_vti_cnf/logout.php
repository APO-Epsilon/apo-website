vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Oct 2012 04:34:08 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{1B1C0106-2560-49B7-86DC-A36CA9A2D92A}
vti_cacheddtm:TX|13 Oct 2012 04:34:08 -0000
vti_filesize:IR|199
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|25 Oct 2012 23:24:33 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{1BD23130-5851-4E4C-90DE-A9AA06928D4B}
vti_cacheddtm:TX|25 Oct 2012 23:24:33 -0000
vti_filesize:IR|3926
vti_backlinkinfo:VX|

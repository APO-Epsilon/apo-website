vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|15 Oct 2012 23:39:28 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{639E2237-D656-425F-9190-CD6C50F5923D}
vti_cacheddtm:TX|15 Oct 2012 23:39:28 -0000
vti_filesize:IR|4434
vti_backlinkinfo:VX|

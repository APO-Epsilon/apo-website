vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Nov 2012 22:02:51 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{965827E2-5636-493D-9FE9-7A5FA3C4B204}
vti_cacheddtm:TX|08 Nov 2012 22:02:51 -0000
vti_filesize:IR|12533
vti_backlinkinfo:VX|

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|08 Nov 2012 22:12:36 -0000
vti_extenderversion:SR|5.0.2.6790
vti_lineageid:SR|{0D7D2B1C-D8BE-4094-AE02-824E74DD066C}
vti_cacheddtm:TX|08 Nov 2012 22:12:36 -0000
vti_filesize:IR|4758
vti_backlinkinfo:VX|

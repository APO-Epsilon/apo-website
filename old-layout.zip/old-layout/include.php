 <?php
 	echo(encode("iso-8859-3", "yes"));
 	?>